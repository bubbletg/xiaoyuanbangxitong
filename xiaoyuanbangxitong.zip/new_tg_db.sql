/*
 Navicat MySQL Data Transfer

 Source Server         : gerenwangz
 Source Server Type    : MySQL
 Source Server Version : 50717
 Source Host           : localhost:3306
 Source Schema         : new_tg_db

 Target Server Type    : MySQL
 Target Server Version : 50717
 File Encoding         : 65001

 Date: 10/06/2018 12:06:56
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user_commodity
-- ----------------------------
DROP TABLE IF EXISTS `user_commodity`;
CREATE TABLE `user_commodity`  (
  `commodity_ID` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '商品ID',
  `commodity` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品名',
  `commodity_price` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品价格',
  `commodity_site` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品地址',
  `merchant` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商家',
  `merchant_No` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商家号码',
  PRIMARY KEY (`commodity_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '商品信息(用于首页显示的商品信息)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_commodity
-- ----------------------------
INSERT INTO `user_commodity` VALUES ('101001', '香蕉', '3.0元每斤', '枣庄学院小西门北边第一家', '爱心水果店', '555656');
INSERT INTO `user_commodity` VALUES ('102031', '此商品未上架', NULL, '改商品为上架', '改商品为上架', NULL);
INSERT INTO `user_commodity` VALUES ('102101', '桃子', '3.0元每斤', '小西门北边', '爱心水果店', '5564145');
INSERT INTO `user_commodity` VALUES ('102111', '五元米饭', '商家未设置', '二号餐厅进门右边', '五元米饭', '1546513');
INSERT INTO `user_commodity` VALUES ('111101', '苹果', '3.0元每斤', '小西门北边', '爱心水果店', '5564145');
INSERT INTO `user_commodity` VALUES ('123141', '米线', '5元每碗', '二餐', '。。。。', '1234444');
INSERT INTO `user_commodity` VALUES ('123451', '面', '5.5元每碗', '二餐', '。。。。', '1234444');
INSERT INTO `user_commodity` VALUES ('132161', '馒头+菜', '商家未设置', '二餐', '。。。。', '1234444');
INSERT INTO `user_commodity` VALUES ('216541', '米饭+菜', '商家未设置', '二餐', '。。。。', '1234444');
INSERT INTO `user_commodity` VALUES ('234781', '洗衣粉', '商家未设置', '达尔文超市', '达尔文超市', '4564567');
INSERT INTO `user_commodity` VALUES ('310211', '洗衣液', '商家未设置', '达尔文超市', '达尔文超市', '4564567');
INSERT INTO `user_commodity` VALUES ('312332', '牙刷，牙膏', '商家未设置', '达尔文超市', '达尔文超市', '4564567');
INSERT INTO `user_commodity` VALUES ('316511', '橡皮檫，文具盒', '商家未设置', '达尔文超市', '达尔文超市', '4564567');
INSERT INTO `user_commodity` VALUES ('321422', '香蕉片，菠萝片', '商家未设置', '达尔文超市', '达尔文超市', '4564567');
INSERT INTO `user_commodity` VALUES ('323541', '味可滋-木瓜牛奶-盒装-240ml', '商家未设置', '袁伟超市', '袁伟超市', '1234444');
INSERT INTO `user_commodity` VALUES ('324511', '伊利-纯牛奶-无菌枕-240ml', '商家未设置', '袁伟超市', '袁伟超市', '1234444');
INSERT INTO `user_commodity` VALUES ('324581', '好点-干脆面-巧克力味-小包装-63g', '商家未设置', '袁伟超市袁伟超市', '袁伟超市', '1234444');
INSERT INTO `user_commodity` VALUES ('457812', 'VC软糖-组合口味-袋装-90g', '商家未设置', '袁伟超市', '袁伟超市', '1234444');
INSERT INTO `user_commodity` VALUES ('541312', '金锣-泡面伴侣香肠-蘑菇味-单支-30g', '商家未设置', '袁伟超市', '袁伟超市', '1234444');
INSERT INTO `user_commodity` VALUES ('654212', '三养-韩国火鸡面-袋装-140g', '商家未设置', '袁伟超市', '袁伟超市', '1234444');
INSERT INTO `user_commodity` VALUES ('849412', '三养-韩国火鸡面-袋装-140g', '商家未设置', '袁伟超市', '袁伟超市', '1234444');
INSERT INTO `user_commodity` VALUES ('849413', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('84941301', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849413045', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('84941310', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('8494131014', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('84941312', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849413121', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849413123', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849413453', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('8494134531', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('8494134535', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849413456', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('84941347', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('84941374', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('84941378', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849413784', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('8494138', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('84941387', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849414', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849415', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849416', '未上架', NULL, NULL, NULL, NULL);
INSERT INTO `user_commodity` VALUES ('849417', '未上架', NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for user_enshrine
-- ----------------------------
DROP TABLE IF EXISTS `user_enshrine`;
CREATE TABLE `user_enshrine`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID_数据库表序号',
  `num_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT 'ID_用户账号',
  `commodity` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品名',
  `commodity_site` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品地址',
  `merchant` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商家',
  `merchant_No` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商家号码',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 145 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户个人收藏' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_enshrine
-- ----------------------------
INSERT INTO `user_enshrine` VALUES (141, '888899', '香蕉', '枣庄学院小西门北边第一家', '爱心水果店', '555656');
INSERT INTO `user_enshrine` VALUES (142, '888888', '桃子', '小西门北边', '爱心水果店', '5564145');
INSERT INTO `user_enshrine` VALUES (143, '888900', '香蕉', '枣庄学院小西门北边第一家', '爱心水果店', '555656');
INSERT INTO `user_enshrine` VALUES (144, '888888', '苹果', '小西门北边', '爱心水果店', '5564145');

-- ----------------------------
-- Table structure for user_jtask
-- ----------------------------
DROP TABLE IF EXISTS `user_jtask`;
CREATE TABLE `user_jtask`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID_数据库表序号',
  `num_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT 'ID_用户账号',
  `name_site` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户收货地址',
  `commodity` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品名',
  `commodity_site` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品地址',
  `time_` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '最晚时间',
  `reward` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户打赏',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '接收任务表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_jtask
-- ----------------------------
INSERT INTO `user_jtask` VALUES (19, '888899', '张乐乐  17863273072  甘肃省 枣庄市  枣庄学院', '米饭加菜', '枣庄学院二餐', '1小时30分钟', '10元');
INSERT INTO `user_jtask` VALUES (20, '888888', '张乐乐  17863273072  甘肃省 枣庄市  枣庄学院', '米饭加菜', '枣庄学院二餐', '1小时30分钟', '10元');
INSERT INTO `user_jtask` VALUES (21, '888899', '田贵  电话：653072  枣庄学院 19号楼327', '实验一号', '实验一号的商品地址', '45分钟', '50元');
INSERT INTO `user_jtask` VALUES (22, '888888', '张乐乐  17863273072  甘肃省 枣庄市  枣庄学院', '米饭加菜', '枣庄学院二餐', '1小时30分钟', '10元');
INSERT INTO `user_jtask` VALUES (23, '888900', '田贵  653072  枣庄学院 19号楼327', '香蕉小西门', '枣庄学院小西门', '2小时', '50元');

-- ----------------------------
-- Table structure for user_table
-- ----------------------------
DROP TABLE IF EXISTS `user_table`;
CREATE TABLE `user_table`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '昵称',
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `sure_password` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '确定密码',
  `mailbox` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `phone` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '手机号码',
  `name` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `ID_card_No` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '身份证号码',
  `site` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地址',
  `site1` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地址1号',
  `site2` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地址2号',
  `site3` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地址3号',
  `site4` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地址4号',
  `Shiming` int(11) NULL DEFAULT NULL COMMENT '判断是否实名：是值为1  否则为0',
  `denglu` int(11) NULL DEFAULT NULL COMMENT '判断是否登录。登录为1，否则为0',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 888901 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '校园行里用户注册基本信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_table
-- ----------------------------
INSERT INTO `user_table` VALUES (888888, '枫叶_情*冷', '363491343', '363491343', 'tg_z@qq.com', '653072', '田贵', '5222******0123   ', 'null', '枣庄学院 19号楼327', NULL, NULL, NULL, 1, NULL);
INSERT INTO `user_table` VALUES (888889, '张乐乐', 'lele', 'lele', '1234@qq.com', '17863271111', '乐乐', '69990122123456789  ', 'nulL', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO `user_table` VALUES (888890, '杨总灵', '3838', '3838', '3838', '111111', 'yang总领', '5222****111**0123', 'NULL', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO `user_table` VALUES (888891, '董小胖', '1111', '1111', '11111111', '123456', 'jskdfj', '8888', 'NULL', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_table` VALUES (888892, '实验3号', '123', '123', '123', '123', '李华   ', '如：5222******0123   ', 'NULL', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_table` VALUES (888893, '实验4号', '123', '123', 'tg_z@qq.com', '17863273072', '李华', '如：5222******0123', 'NULL', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO `user_table` VALUES (888894, '123456', '123456', '123456', '请输入邮箱', '123456', '李华', '5222******0123', NULL, NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO `user_table` VALUES (888895, '昵称1', '123', '123', '请输入邮箱', '123', 'XIANGMING', '5222******0123', NULL, NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO `user_table` VALUES (888896, '123456111', '1111', '1111', '请输入邮箱', '111', '系统设置01', '111100000000000000000000000000001', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_table` VALUES (888897, '实验4', '123', '123', '请输入邮箱', '123', '系统设置01', '111100000000000000000000000000001', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_table` VALUES (888898, '实验几号了', '123', '123', '123', '123', '李华', '5222***00***0123', NULL, NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO `user_table` VALUES (888899, '最爽。', '123', '123', 'tg_z@qq.com', '17863273072', '张乐乐', '12345678987654321', NULL, '甘肃省 枣庄市  枣庄学院', NULL, NULL, NULL, 1, NULL);
INSERT INTO `user_table` VALUES (888900, '昵称实验五号', '123', '123', 'tg_z@qq.com', '17863273072', '李华实验⑤', '5222******0123', NULL, NULL, NULL, NULL, NULL, 1, NULL);

-- ----------------------------
-- Table structure for user_task
-- ----------------------------
DROP TABLE IF EXISTS `user_task`;
CREATE TABLE `user_task`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID_数据库表序号',
  `num_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT 'ID_用户账号',
  `name_site` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户收货地址',
  `commodity` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品名',
  `commodity_site` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品地址',
  `time_` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '最晚时间',
  `reward` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户打赏',
  `if_js` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用于判断该任务是否被接收（1 接收   0  否）',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '发布任务管理表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_task
-- ----------------------------
INSERT INTO `user_task` VALUES (24, '888899', '张乐乐  17863273072  甘肃省 枣庄市  枣庄学院', '米饭加菜', '枣庄学院二餐', '1小时30分钟', '10元', '10');
INSERT INTO `user_task` VALUES (25, '888888', '田贵  653072  枣庄学院 19号楼327', '香蕉小西门', '枣庄学院小西门', '2小时', '50元', '10');
INSERT INTO `user_task` VALUES (26, '888888', '田贵  电话：653072  枣庄学院 19号楼327', '实验一号', '实验一号的商品地址', '45分钟', '50元', '10');
INSERT INTO `user_task` VALUES (27, '888888', '田贵  653072  枣庄学院 19号楼327', '实验3号', '实验3号的地址', '1小时45分钟', '10', '10');
INSERT INTO `user_task` VALUES (28, '888900', '李华实验⑤  17863273072  null', '123实验5', '123实验5地址', '1小时15分钟', '50元', '10');

SET FOREIGN_KEY_CHECKS = 1;
