/*
 * �����û��ղص����ݿ������
 */
package pers.tg.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

import pers.tg.pean.user_enshrine;
import pers.tg.realize.Home_Page;
import pers.tg.realize.MyButtonJPanel;

public class Enshrine {
	Statement stmt=null;
	ResultSet rs=null;
	public Enshrine() {
		// TODO Auto-generated constructor stub
	}
	public void insert(user_enshrine enshrine) {   //���ݿ����
		Connection con=new DBConnection().getConncetion();  //ͨ��DBConnection���ȡ���ݿ�����

		String sql="insert into user_enshrine (num_id,commodity,commodity_site,merchant,merchant_No)values(?,?,?,?,?)";
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);    
			pstmt.setString(1, enshrine.getNum_id());
			pstmt.setString(2, enshrine.getCommodity());
			pstmt.setString(3, enshrine.getCommodity_site());
			pstmt.setString(4, enshrine.getMerchant());
			pstmt.setString(5, enshrine.getMerchant_No());
			pstmt.executeUpdate();		//���浽���ݿ���
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				con=null;
			}
		}
	}
	
	public static void show(String id) {   //�ղ����ݿ��ѯ
		Connection con=new DBConnection().getConncetion();  //ͨ��DBConnection���ȡ���ݿ�����
		for (int i = 0; i < MyButtonJPanel.rowData.length;i++) {        //�������˺ŵ�¼ʱ�����ԭ�������������ֵ
		for (int j = 0; j < MyButtonJPanel.rowData[i].length; j++) {
			MyButtonJPanel.rowData[i][j]=null;
		}
		}
		String sql="select num_id,commodity,commodity_site,merchant,merchant_No from user_enshrine";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs1 = pstmt.executeQuery();
			for (int i = 0; i < MyButtonJPanel.rowData.length;) {
				for (int j = 0; j < MyButtonJPanel.rowData[i].length; j++) {
					MyButtonJPanel.rowData[i][j]=null;
				}
				if(!rs1.next())break;    //�����ݿ�����Ϊ�յ�ʱ�����˳�ѭ��
				if (rs1.getString("num_id").equals(id)) // ���ҵ���ǰ�˺ŵ��ղ�
				{
					for (int j = 0; j < MyButtonJPanel.rowData[i].length; j++) {
						MyButtonJPanel.rowData[i][j] = rs1.getString(j + 2);
					}
					i++;
				}
			}
			MyButtonJPanel.enshrine_shows.repaint(); // ���»���
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				con=null;
			}
		}
	}
}
