/*
 * �������������
 */

package pers.tg.pean;

public class user_Jtask {

	private int ID;
	private String num_id;   //�˺�
	private String name_site;  //���˵�ַ
	private String commodity;  //��Ʒ
	private String commodity_site;//��Ʒ��ַ
	private String time_;     //�û�Ҫ�������ջ�ʱ��
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getNum_id() {
		return num_id;
	}
	public void setNum_id(String num_id) {
		this.num_id = num_id;
	}
	public String getName_site() {
		return name_site;
	}
	public void setName_site(String name_site) {
		this.name_site = name_site;
	}
	public String getCommodity() {
		return commodity;
	}
	public void setCommodity(String commodity) {
		this.commodity = commodity;
	}
	public String getCommodity_site() {
		return commodity_site;
	}
	public void setCommodity_site(String commodity_site) {
		this.commodity_site = commodity_site;
	}
	public String getTime_() {
		return time_;
	}
	public void setTime_(String time_) {
		this.time_ = time_;
	}
	public String getReward() {
		return reward;
	}
	public void setReward(String reward) {
		this.reward = reward;
	}
	private String reward;  //�û�����
}
