//����������Ʒ�ͻ�ȡ��Ʒ��Ϣ
package pers.tg.pean;

public class user_commodity {

	private long commodity_ID;  //��ƷID 
	private String commodity;    //��Ʒ��
	private String commodity_price; //��Ʒ��Ǯ
	private String commodity_site;//��Ʒ��ַ
	private String merchant; //�̼�����
	private String merchant_No; //�̼Һ���
	
	public user_commodity() {
	}

	public long getCommodity_ID() {
		return commodity_ID;
	}

	public void setCommodity_ID(long commodity_ID) {
		this.commodity_ID = commodity_ID;
	}

	public String getCommodity() {
		return commodity;
	}

	public void setCommodity(String commodity) {
		this.commodity = commodity;
	}

	public String getCommodity_price() {
		return commodity_price;
	}

	public void setCommodity_price(String commodity_price) {
		this.commodity_price = commodity_price;
	}

	public String getCommodity_site() {
		return commodity_site;
	}

	public void setCommodity_site(String commodity_site) {
		this.commodity_site = commodity_site;
	}

	public String getMerchant() {
		return merchant;
	}

	public void setMerchant(String merchant) {
		this.merchant = merchant;
	}

	public String getMerchant_No() {
		return merchant_No;
	}

	public void setMerchant_No(String merchant_No) {
		this.merchant_No = merchant_No;
	}
	
	
}
