  /*
   * �����û��ղز����ı�
   */
package pers.tg.pean;

public class user_enshrine {
	private int ID;  //�˺�
	private String num_id;
	
	private String commodity;//��Ʒ����
	private String commodity_site;//��Ʒ��ַ
	private String merchant;//�̼�
	private String merchant_No;//�̼Һ���
	public user_enshrine() {
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getNum_id() {
		return num_id;
	}
	public void setNum_id(String num_id) {
		this.num_id = num_id;
	}
	public String getCommodity() {
		return commodity;
	}
	public void setCommodity(String commodity) {
		this.commodity = commodity;
	}
	public String getCommodity_site() {
		return commodity_site;
	}
	public void setCommodity_site(String commodity_site) {
		this.commodity_site = commodity_site;
	}
	public String getMerchant() {
		return merchant;
	}
	public void setMerchant(String merchant) {
		this.merchant = merchant;
	}
	public String getMerchant_No() {
		return merchant_No;
	}
	public void setMerchant_No(String merchant_No) {
		this.merchant_No = merchant_No;
	}

}
