/*
 * ���������
 */

package pers.tg.pean;

public class user_task {

	public static int ID;
	public static String num_id;   //�˺�
	public static String name_site;  //���˵�ַ
	public static String commodity;  //��Ʒ
	public static String commodity_site;//��Ʒ��ַ
	public static String time_;     //�û�Ҫ�������ջ�ʱ��
	public static String reward;  //�û�����
	public static  String if_js;  //�����ж��Ƿ���ն���
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public static String getNum_id() {
		return num_id;
	}
	public static void setNum_id(String num_id1) {
		num_id = num_id1;
	}
	public static String getName_site() {
		return name_site;
	}
	public static void setName_site(String name_site1) {
		name_site = name_site1;
	}
	public static String getCommodity() {
		return commodity;
	}
	public static void setCommodity(String commodity1) {
		commodity = commodity1;
	}
	public static String getCommodity_site() {
		return commodity_site;
	}
	public static void setCommodity_site(String commodity_site1) {
		commodity_site = commodity_site1;
	}
	public static String getTime_() {
		return time_;
	}
	public static void setTime_(String time_1) {
		time_ = time_1;
	}
	public static String getReward() {
		return reward;
	}
	public static void setReward(String reward1) {
		reward = reward1;
	}
	public static  String getIf_js() {
		return if_js;
	}
	public  static void setIf_js(String if_js1) {
	if_js = if_js1;
	}
	
}
