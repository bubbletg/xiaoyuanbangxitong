package pers.tg.pean;  //���ڴ�������Ϣ

public class user_table {
	private int ID;  //�˺ţ��Զ�����
	private String nickname;  //�ǳ�
	private String password;  //����
	private String sure_password;  //ȷ������
	private String mailbox;  //����
	private String phone;  //�绰����
	private String name;  //����
	private String ID_card_No;  //����֤����
	private int Shiming;   //�����ж��Ƿ�ʵ���Ǽ�
	private int denglu;   //�����ж��Ƿ��¼
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
		System.out.println(nickname);
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSure_password() {
		return sure_password;
	}
	public void setSure_password(String sure_password) {
		this.sure_password = sure_password;
	}
	public String getMailbox() {
		return mailbox;
	}
	public void setMailbox(String mailbox) {
		this.mailbox = mailbox;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getID_card_No() {
		return ID_card_No;
	}
	public void setID_card_No(String iD_card_No) {
		ID_card_No = iD_card_No;
	}
	public int getShiming() {
		return Shiming;
	}
	public void setShiming(int shiming) {
		Shiming = shiming;
	}
	public int getdenglu() {
		return denglu;
	}
	public void setdenglu(int denglu) {
		this.denglu = denglu;
	}

}
