CREATE DATABASE  IF NOT EXISTS `new_tg_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `new_tg_db`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: new_tg_db
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_table`
--

DROP TABLE IF EXISTS `user_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_table` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) NOT NULL COMMENT '昵称',
  `password` varchar(20) DEFAULT NULL COMMENT '密码',
  `sure_password` varchar(40) DEFAULT NULL COMMENT '确定密码',
  `mailbox` varchar(40) DEFAULT NULL COMMENT '邮箱',
  `phone` mediumtext COMMENT '手机号码',
  `name` varchar(40) DEFAULT NULL COMMENT '姓名',
  `ID_card_No` mediumtext COMMENT '身份证号码',
  `site` varchar(45) DEFAULT NULL COMMENT '地址',
  `site1` varchar(45) DEFAULT NULL COMMENT '地址1号',
  `site2` varchar(45) DEFAULT NULL COMMENT '地址2号',
  `site3` varchar(45) DEFAULT NULL COMMENT '地址3号',
  `site4` varchar(45) DEFAULT NULL COMMENT '地址4号',
  `Shiming` int(11) DEFAULT NULL COMMENT '判断是否实名：是值为1  否则为0',
  `denglu` int(11) DEFAULT NULL COMMENT '判断是否登录。登录为1，否则为0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=888901 DEFAULT CHARSET=utf8 COMMENT='校园行里用户注册基本信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_table`
--

LOCK TABLES `user_table` WRITE;
/*!40000 ALTER TABLE `user_table` DISABLE KEYS */;
INSERT INTO `user_table` VALUES (888888,'枫叶_情*冷','363491343','363491343','tg_z@qq.com','653072','田贵','5222******0123   ','null','枣庄学院 19号楼327',NULL,NULL,NULL,1,NULL),(888889,'张乐乐','lele','lele','1234@qq.com','17863271111','乐乐','69990122123456789  ','nulL',NULL,NULL,NULL,NULL,1,NULL),(888890,'杨总灵','3838','3838','3838','111111','yang总领','5222****111**0123','NULL',NULL,NULL,NULL,NULL,1,NULL),(888891,'董小胖','1111','1111','11111111','123456','jskdfj','8888','NULL',NULL,NULL,NULL,NULL,NULL,NULL),(888892,'实验3号','123','123','123','123','李华   ','如：5222******0123   ','NULL',NULL,NULL,NULL,NULL,NULL,NULL),(888893,'实验4号','123','123','tg_z@qq.com','17863273072','李华','如：5222******0123','NULL',NULL,NULL,NULL,NULL,1,NULL),(888894,'123456','123456','123456','请输入邮箱','123456','李华','5222******0123',NULL,NULL,NULL,NULL,NULL,1,NULL),(888895,'昵称1','123','123','请输入邮箱','123','XIANGMING','5222******0123',NULL,NULL,NULL,NULL,NULL,1,NULL),(888896,'123456111','1111','1111','请输入邮箱','111','系统设置01','111100000000000000000000000000001',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(888897,'实验4','123','123','请输入邮箱','123','系统设置01','111100000000000000000000000000001',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(888898,'实验几号了','123','123','123','123','李华','5222***00***0123',NULL,NULL,NULL,NULL,NULL,1,NULL),(888899,'最爽。','123','123','tg_z@qq.com','17863273072','张乐乐','12345678987654321',NULL,'甘肃省 枣庄市  枣庄学院',NULL,NULL,NULL,1,NULL),(888900,'昵称实验五号','123','123','tg_z@qq.com','17863273072','李华实验⑤','5222******0123',NULL,NULL,NULL,NULL,NULL,1,NULL);
/*!40000 ALTER TABLE `user_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-14 22:16:06
