CREATE DATABASE  IF NOT EXISTS `new_tg_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `new_tg_db`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: new_tg_db
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_commodity`
--

DROP TABLE IF EXISTS `user_commodity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_commodity` (
  `commodity_ID` varchar(45) NOT NULL COMMENT '商品ID',
  `commodity` varchar(50) DEFAULT NULL COMMENT '商品名',
  `commodity_price` varchar(45) DEFAULT NULL COMMENT '商品价格',
  `commodity_site` varchar(45) DEFAULT NULL COMMENT '商品地址',
  `merchant` varchar(45) DEFAULT NULL COMMENT '商家',
  `merchant_No` varchar(45) DEFAULT NULL COMMENT '商家号码',
  PRIMARY KEY (`commodity_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品信息(用于首页显示的商品信息)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_commodity`
--

LOCK TABLES `user_commodity` WRITE;
/*!40000 ALTER TABLE `user_commodity` DISABLE KEYS */;
INSERT INTO `user_commodity` VALUES ('101001','香蕉','3.0元每斤','枣庄学院小西门北边第一家','爱心水果店','555656'),('102031','此商品未上架',NULL,'改商品为上架','改商品为上架',NULL),('102101','桃子','3.0元每斤','小西门北边','爱心水果店','5564145'),('102111','五元米饭','商家未设置','二号餐厅进门右边','五元米饭','1546513'),('111101','苹果','3.0元每斤','小西门北边','爱心水果店','5564145'),('123141','米线','5元每碗','二餐','。。。。','1234444'),('123451','面','5.5元每碗','二餐','。。。。','1234444'),('132161','馒头+菜','商家未设置','二餐','。。。。','1234444'),('216541','米饭+菜','商家未设置','二餐','。。。。','1234444'),('234781','洗衣粉','商家未设置','达尔文超市','达尔文超市','4564567'),('310211','洗衣液','商家未设置','达尔文超市','达尔文超市','4564567'),('312332','牙刷，牙膏','商家未设置','达尔文超市','达尔文超市','4564567'),('316511','橡皮檫，文具盒','商家未设置','达尔文超市','达尔文超市','4564567'),('321422','香蕉片，菠萝片','商家未设置','达尔文超市','达尔文超市','4564567'),('323541','味可滋-木瓜牛奶-盒装-240ml','商家未设置','袁伟超市','袁伟超市','1234444'),('324511','伊利-纯牛奶-无菌枕-240ml','商家未设置','袁伟超市','袁伟超市','1234444'),('324581','好点-干脆面-巧克力味-小包装-63g','商家未设置','袁伟超市袁伟超市','袁伟超市','1234444'),('457812','VC软糖-组合口味-袋装-90g','商家未设置','袁伟超市','袁伟超市','1234444'),('541312','金锣-泡面伴侣香肠-蘑菇味-单支-30g','商家未设置','袁伟超市','袁伟超市','1234444'),('654212','三养-韩国火鸡面-袋装-140g','商家未设置','袁伟超市','袁伟超市','1234444'),('849412','三养-韩国火鸡面-袋装-140g','商家未设置','袁伟超市','袁伟超市','1234444'),('849413','未上架',NULL,NULL,NULL,NULL),('84941301','未上架',NULL,NULL,NULL,NULL),('849413045','未上架',NULL,NULL,NULL,NULL),('84941310','未上架',NULL,NULL,NULL,NULL),('8494131014','未上架',NULL,NULL,NULL,NULL),('84941312','未上架',NULL,NULL,NULL,NULL),('849413121','未上架',NULL,NULL,NULL,NULL),('849413123','未上架',NULL,NULL,NULL,NULL),('849413453','未上架',NULL,NULL,NULL,NULL),('8494134531','未上架',NULL,NULL,NULL,NULL),('8494134535','未上架',NULL,NULL,NULL,NULL),('849413456','未上架',NULL,NULL,NULL,NULL),('84941347','未上架',NULL,NULL,NULL,NULL),('84941374','未上架',NULL,NULL,NULL,NULL),('84941378','未上架',NULL,NULL,NULL,NULL),('849413784','未上架',NULL,NULL,NULL,NULL),('8494138','未上架',NULL,NULL,NULL,NULL),('84941387','未上架',NULL,NULL,NULL,NULL),('849414','未上架',NULL,NULL,NULL,NULL),('849415','未上架',NULL,NULL,NULL,NULL),('849416','未上架',NULL,NULL,NULL,NULL),('849417','未上架',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user_commodity` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-14 22:16:05
