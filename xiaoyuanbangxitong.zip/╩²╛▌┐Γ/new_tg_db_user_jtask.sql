CREATE DATABASE  IF NOT EXISTS `new_tg_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `new_tg_db`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: new_tg_db
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_jtask`
--

DROP TABLE IF EXISTS `user_jtask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_jtask` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID_数据库表序号',
  `num_id` varchar(20) DEFAULT '' COMMENT 'ID_用户账号',
  `name_site` varchar(45) DEFAULT NULL COMMENT '用户收货地址',
  `commodity` varchar(100) DEFAULT NULL COMMENT '商品名',
  `commodity_site` varchar(45) DEFAULT NULL COMMENT '商品地址',
  `time_` varchar(45) DEFAULT NULL COMMENT '最晚时间',
  `reward` varchar(45) DEFAULT NULL COMMENT '用户打赏',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='接收任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_jtask`
--

LOCK TABLES `user_jtask` WRITE;
/*!40000 ALTER TABLE `user_jtask` DISABLE KEYS */;
INSERT INTO `user_jtask` VALUES (19,'888899','张乐乐  17863273072  甘肃省 枣庄市  枣庄学院','米饭加菜','枣庄学院二餐','1小时30分钟','10元'),(20,'888888','张乐乐  17863273072  甘肃省 枣庄市  枣庄学院','米饭加菜','枣庄学院二餐','1小时30分钟','10元'),(21,'888899','田贵  电话：653072  枣庄学院 19号楼327','实验一号','实验一号的商品地址','45分钟','50元'),(22,'888888','张乐乐  17863273072  甘肃省 枣庄市  枣庄学院','米饭加菜','枣庄学院二餐','1小时30分钟','10元'),(23,'888900','田贵  653072  枣庄学院 19号楼327','香蕉小西门','枣庄学院小西门','2小时','50元');
/*!40000 ALTER TABLE `user_jtask` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-14 22:16:06
